
import math
import random

import pygame

from scripts.particle import Particle
from scripts.spark import Spark

class PhysicsEntity:
    def __init__(self, game, e_type, pos, size):
        self.game = game
        self.type = e_type
        self.pos = list(pos)        # creates unique pos lists for each class
        self.size = size
        self.velocity = [0, 0]
        self.collisions = {"up": False, "down": False, "right": False, "left": False}

        self.action = ''
        self.anim_offset = (-3, -3)     # Hack to make the entity sprites line up
        self.flip = False
        self.set_action('idle')
        self.flipped_images = {}    # Delete
        self.last_movement = [0, 0]

    def rect(self):     # generates a Rect dynamically
        return pygame.Rect(self.pos[0], self.pos[1], self.size[0], self.size[1])
    
    def set_action(self, action):
        if action != self.action:    # Activate when the action changes. Otherwise, animation is stuck on index=0
            self.action = action
            self.animation = self.game.assets[self.type + '/' + self.action].copy()

    def update(self, tilemap, movement=(0,0)):       # runs every frame
        self.collisions = {"up": False, "down": False, "right": False, "left": False}

        # TODO:
        # Wall jumping then immediatly moving witht he wall jump's momentum gives a large boost to horizontal velocity.
        # This is kind of cool. Maybe keeps this?
        frame_movment = (movement[0] * 1.2 + self.velocity[0], movement[1] + self.velocity[1])

        self.pos[0] += frame_movment[0]     # update X position
        entity_rect = self.rect()
        # Check for collision on the domain
        for rect in tilemap.physics_rects_around(self.pos):
            if entity_rect.colliderect(rect):
                if frame_movment[0] > 0:        # moving right
                    entity_rect.right = rect.left   # snap rect's edges together
                    self.collisions["right"] = True
                if frame_movment[0] < 0:        # moving left
                    entity_rect.left = rect.right
                    self.collisions["left"] = True
                self.pos[0] = entity_rect.x     #update player position

        self.pos[1] += frame_movment[1]     # update Y position
        entity_rect = self.rect()
        # Check for collision in the range
        for rect in tilemap.physics_rects_around(self.pos):
            if entity_rect.colliderect(rect):
                if frame_movment[1] > 0:        # moving down
                    entity_rect.bottom = rect.top   # snap rect's edges together 
                    self.collisions["down"] = True
                if frame_movment[1] < 0:        # moving up
                    entity_rect.top = rect.bottom
                    self.collisions["up"] = True
                self.pos[1] = entity_rect.y     #update player position

        if movement[0] > 0:     # sets image orientation right
            self.flip = False
        if movement[0] < 0:     # sets image orientation left
            self.flip = True

        self.last_movement = movement

        self.velocity[1] = min(5, self.velocity[1] + 0.16)       # Terminal velocity = 5; if not at terminal velocity, at 0.1 to y velocity

        if self.collisions["down"] or self.collisions["up"]:    # When colliding vertically, set y velocity to 0
            self.velocity[1] = 0

        self.animation.update()

    def render(self, surf, offset = (0, 0)):
        surf.blit(
            pygame.transform.flip(self.animation.img(),self.flip, False),                                       # orients image (left/right)
            (self.pos[0] - offset[0] + self.anim_offset[0], self.pos[1] - offset[1] + self.anim_offset[1])      # image position
        )
    

class Enemy(PhysicsEntity):
    def __init__(self, game, pos, size):
        super().__init__(game, 'enemy', pos, size)

        self.walking = 0        # Between movements timer

    def update(self, tilemap, movement=(0, 0)):
        if self.walking:
            # Check if block in front and below exists
            if tilemap.solid_check((
                self.rect().centerx + (-7  if self.flip else 7),        # Check from center to edge of img
                self.pos[1] + 23                                        # Check 5 px below top of img
            )):
                # Check for wall collision
                if (self.collisions['right'] or (self.collisions['left'])):
                    self.flip = not self.flip
                else:
                    movement = (movement[0] - 0.5 if self.flip else 0.5, movement[1])
            else:
                self.flip = not self.flip
            self.walking = max(0, self.walking - 1)     # Countdown timer
            if not self.walking:        # activates on last frame
                dis = (self.game.player.pos[0] - self.pos[0], self.game.player.pos[1] - self.pos[1])        # get distance from self to player
                # create projectile when y-cor is with-in one tile
                if (abs(dis[1]) < 16):
                    if (self.flip and dis[0] < 0):          # player is left and self facing left
                        self.game.sfx['shoot'].play()
                        self.game.projectiles.append([[self.rect().centerx - 7, self.rect().centery], -1.5, 0])
                        for i in range(4):
                            self.game.sparks.append(Spark(self.game.projectiles[-1][0], random.random() - 0.5 + math.pi, 2 + random.random()))
                    if (not self.flip and dis[0] > 0):      # player is right and self facing right
                        self.game.sfx['shoot'].play()
                        self.game.projectiles.append([[self.rect().centerx + 7, self.rect().centery], 1.5, 0])
                        for i in range(4):
                            self.game.sparks.append(Spark(self.game.projectiles[-1][0], random.random() - 0.5, 2 + random.random()))
        elif random.random() < 0.01:
            self.walking = random.randint(30, 120)

        super().update(tilemap, movement=movement)

        # Set movement animations
        if movement[0] != 0:
            self.set_action('run')
        else:
            self.set_action('idle')

        # Kill Enemy with dash
        if abs(self.game.player.dashing) >= 3:
            if self.rect().colliderect(self.game.player.rect()):        # if enemy collides with player
                self.game.screenshake = max(16, self.game.screenshake)
                self.game.sfx['hit'].play()
                for i in range(30):
                    angle = random.random() * math.pi * 2
                    speed = random.random() * 5
                    self.game.sparks.append(Spark(self.rect().center, angle, 2 + random.random()))
                    self.game.particles.append(Particle(
                        self.game,
                        'particle',
                        self.rect().center,
                        velocity=[math.cos(angle + math.pi) * speed * 0.5, math.sin(angle + math.pi) * speed * 0.5],
                        frame=random.randint(0, 7)
                    ))
                    self.game.sparks.append(Spark(self.rect().center, 0, 5 + random.random()))          # add spark horizontally
                    self.game.sparks.append(Spark(self.rect().center, math.pi, 5 + random.random()))    # add spark horizontally
                return True

    def render(self, surf, offset=(0, 0)):
        super().render(surf, offset=offset)

        if self.flip:
            surf.blit(
                pygame.transform.flip(self.game.assets['gun'], True, False),
                (
                    self.rect().centerx - 4 - self.game.assets['gun'].get_width() - offset[0],      # Set x-cor placement
                    self.rect().centery - offset[1]                                                 # Set y-cor placement
                )
            )
        else:
            surf.blit(
                self.game.assets['gun'],
                (
                    self.rect().centerx + 4  - offset[0],
                    self.rect().centery - offset[1]
                )
            )
    

class Player(PhysicsEntity):
    def __init__(self, game, pos, size):
        super().__init__(game, 'player', pos, size)
        self.air_time = 0
        self.jumps = 1
        self.wall_slide = False
        self.dash_count = 1
        self.dashing = 0        # dash timer

    def update(self, tilemap, movement=(0, 0)):
        super().update(tilemap, movement=movement)

        self.air_time += 1

        # Incase player escapes the death blocks
        if self.air_time > 720:
            # not needed because update won't run if player is dead
            if not self.game.dead:
                self.game.screenshake = max(16, self.game.screenshake)
            self.game.dead += 1
        
        if tilemap.trap_check((self.pos[0] + 5, self.pos[1] + 7)) == "spike":
            self.game.dead += 1
        elif tilemap.trap_check((self.pos[0], self.pos[1] + 18)) == "fall":
            tilemap.fall_trap((self.pos[0] // 1, (self.pos[1] + 18) // 1))

        if self.collisions['down']:
            self.air_time = 0
            self.jumps = 1      # reset jump counter
            if not self.dashing:
                self.dash_count = 1
                
        # Wall-slide Check and handeling
        self.wall_slide = False     # fires an "event" every frame
        if (self.collisions['right'] or self.collisions['left']) and self.air_time > 4:
            self.wall_slide = True
            self.velocity[1] = min(self.velocity[1], 0.5)       # ease downward velocity to a cap of 0.5
            # Check and set for right vs left facing wall-slide
            if self.collisions['right']:
                self.flip = False
            else:
                self.flip = True
            self.set_action('wall_slide')       # update animation state

        if not self.wall_slide:
            # Change animations
            if self.air_time > 4 and self.air_time < 10:
                self.set_action('pick')
            elif self.air_time >= 10:
                self.set_action('jump')
            elif movement[0] != 0:
                self.set_action('run')
            else:
                self.set_action('idle')

        # Burst of particles at end of dash
        if abs(self.dashing) in {12, 2}:
            for i in range(20):
                angle = random.random() * math.pi * 2                               # Set random angle in 2pi rad (360 deg)
                speed = random.random() * 0.5 + 0.5                                 # Set random speed between 0.5 - 1
                pvelocity = [math.cos(angle) * speed, math.sin(angle) * speed]      # Set the x and y velocities
                self.game.particles.append(
                    Particle(self.game, 'particle', self.rect().center, velocity=pvelocity, frame=random.randint(0, 7))
                )
        # manage dashing timer
        if self.dashing > 0:
            self.dashing = max(0, self.dashing - 1)
        if self.dashing < 0:
            self.dashing = min(0, self.dashing + 1)
        # manage dash speed and stream of particles
        if abs(self.dashing) > 2:
            # self.velocity[0] = abs(self.dashing) / self.dashing * 8
            self.velocity[0] = (abs(self.dashing) / self.dashing) * 10
            # self.velocity[1] = (abs(self.dashing) / self.dashing) * 7
            # on 9th frame severely cut dash speed
            # then let normal speed reduction take over
            # last 50 frames act as cooldown
            if self.collisions['right'] or self.collisions['left']:
                self.velocity[1] = 0
            if abs(self.dashing) == 3:
                self.velocity[0] *= 0.1
                # self.velocity[1] *= 0.1
            pvelocity = [abs(self.dashing) / self.dashing * random.random() * 3, 0]
            self.game.particles.append(
                Particle(self.game, 'particle', self.rect().center, velocity=pvelocity, frame=random.randint(0, 7))
            )

        # horizontal "air-resistance"
        if self.velocity[0] > 0:
            self.velocity[0] = max(self.velocity[0] - 0.3, 0)
        else:
            self.velocity[0] = min(self.velocity[0] + 0.3, 0)

    def render(self, surf, offset=(0, 0)):
        if abs(self.dashing) <= 2:             # if dash is on cooldown or not active
            super().render(surf, offset=offset)     # Do NOT render the player

    
    def jump(self):
        # Coyote Time
        if self.air_time > 9:
            self.jumps = 0
            
        if self.wall_slide:
            if self.flip and self.last_movement[0] < 0:     # if facing left and movement going to left
                self.velocity[0] = 4.9
                self.velocity[1] = -2.0
                self.air_time = 5
                self.jumps = max(0, self.jumps - 1)
                return True     # Useful if check for a wall JUMP is needed, i.e an animation
            elif not self.flip and self.last_movement[0] > 0:
                self.velocity[0] = -4.9
                self.velocity[1] = -2.0
                self.air_time = 5
                self.jumps = max(0, self.jumps - 1)
                return True     # Useful if check for a wall JUMP is needed, i.e an animation
            
        elif self.jumps:
            self.velocity[1] = -3.2
            self.jumps -= 1
            self.air_time = 5       # forces jump animation to play
            return True

    def dash(self):
        if not self.dashing and self.dash_count:
            self.dash_count = 0
            self.game.sfx['dash'].play()
            if self.flip:       # if facing left
                self.dashing = -12
            else:
                self.dashing = 12
