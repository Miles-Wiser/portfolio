
import json
import pygame

AUTOTILE_MAP = {
    # 3x3 grid
    tuple(sorted([(1, 0), (0, 1)])): 0,                         # Top-Left
    tuple(sorted([(1, 0), (0, 1), (-1, 0)])): 1,                # Top-Middle
    tuple(sorted([(-1, 0), (0, 1)])): 2,                        # Top-Right
    tuple(sorted([(-1, 0), (0, -1), ((0, 1))])): 3,             # Right-Middle
    tuple(sorted([(-1, 0), (0, -1)])): 4,                       # Bottom-Right
    tuple(sorted([(-1, 0), (0, -1), (1, 0)])): 5,               # Bottom-Middle
    tuple(sorted([(1, 0), (0, -1)])): 6,                        # Bottom-Left
    tuple(sorted([(1, 0), (0, -1), (0, 1)])): 7,                # Left-Middle
    tuple(sorted([(1, 0), (-1, 0), (0, 1), (0, -1)])): 8,       # Center
    # 1x1 grid
    tuple(sorted([])): 13,                                      # Single
    # pillar
    tuple(sorted([(0, 1)])): 16,                                # Top
    tuple(sorted([(0, 1), (0, -1)])): 14,                       # Center
    tuple(sorted([(0, -1)])): 15,                               # Bottom  
    # Overhang
    tuple(sorted([(1, 0)])): 17,                                # Left
    tuple(sorted([(-1, 0)])): 18,                               # Right
}

NEIGHBOR_OFFSETS = [    # the 24 surrounding and 1 inside blocks for the player
    (-2, -2), (-1, -2), (0, -2), (1, -2), (2, -2),
    (-2, 1), (-1, -1), (0, -1), (1, -1), (2, 1),
    (-2, 0), (-1, 0), (0, 0), (1, 0), (2, 0),
    (-2, 1), (-1, 1), (0, 1), (1, 1), (2, 1),
    (-2, 2), (-1, 2), (0, 2), (1, 2), (2, 2)
]
PHYSICS_TILES = {"grass", "snow", "transition", "cloud"}  # collide-able tile types
SPIKE_TILES = {'spike', 'icicle', 'death'}
FALL_TILES = {'cloud'}
AUTOTILE_TYPES = {"grass", "snow"}

class Tilemap:
    def __init__(self, game, tile_size=8):
        self.game = game
        self.tile_size = tile_size
        self.tilemap = {}           # Tiles on a grid
        self.offgrid_tiles = []     # Tiles that may or may not align with the grid

    def extract(self, id_pairs, keep=False):
        matches = []
        for tile in self.offgrid_tiles.copy():
            if (tile['type'], tile['variant']) in id_pairs:
                matches.append(tile.copy())
                if not keep:
                    self.offgrid_tiles.remove(tile)

        for loc in self.tilemap:
            tile = self.tilemap[loc]
            if (tile['type'], tile['variant']) in id_pairs:
                matches.append(tile.copy())
                # convert tile coordinates from grid to pixels
                matches[-1]['pos'] = matches[-1]['pos'].copy()      #target key in the key-value pair
                matches[-1]['pos'][0] *= self.tile_size             # target x-cor
                matches[-1]['pos'][1] *= self.tile_size             # target y-cor
                if not keep:
                    self.tilemap[loc]

        return matches

    def tiles_around(self, pos):
        tiles = []
        tile_loc = (int(pos[0] // self.tile_size), int(pos[1] // self.tile_size))  # // = int division

        # check if the position is in surrounding tiles
        for offset in NEIGHBOR_OFFSETS:
            check_loc = str(tile_loc[0] + offset[0]) + ';' + str(tile_loc[1] + offset[1])
            if check_loc in self.tilemap:
                tiles.append(self.tilemap[check_loc])
        return tiles    # return tiles that are in that position
    
    def save(self, path):
        f = open(path, 'w')
        json.dump(
            {
                'tilemap': self.tilemap,
                'tile_size': self.tile_size,
                'offgrid': self.offgrid_tiles
            },
            f
        )
        f.close()

    def load(self, path):
        f = open(path, 'r')
        map_data = json.load(f)
        f.close()

        self.tilemap = map_data['tilemap']
        self.tile_size = map_data['tile_size']
        self.offgrid_tiles = map_data['offgrid']

    def solid_check(self, pos):
        tile_loc = str(int(pos[0] // self.tile_size)) + ';' + str(int(pos[1] // self.tile_size))
        if tile_loc in self.tilemap:
            if self.tilemap[tile_loc]['type'] in PHYSICS_TILES:
                return self.tilemap[tile_loc]
            
    def trap_check(self, pos):
        tile_loc = str(int(pos[0] // self.tile_size)) + ';' + str(int(pos[1] // self.tile_size))
        if tile_loc in self.tilemap:
            if self.tilemap[tile_loc]['type'] in SPIKE_TILES:
                return "spike"
            elif self.tilemap[tile_loc]['type'] in FALL_TILES:
                return "fall"
            
    def fall_trap(self, pos):
        tile_loc = str(int(pos[0] // self.tile_size)) + ';' + str(int(pos[1] // self.tile_size))
        self.tilemap[tile_loc]['type'] = 'cloud_active'
        # self.tilemap[tile_loc]['type']['variant'] = 0

    
    def physics_rects_around(self, pos):
        rects = []
        for tile in self.tiles_around(pos):
            if tile["type"] in PHYSICS_TILES:
                rects.append(
                    pygame.Rect(
                        tile["pos"][0] * self.tile_size, tile["pos"][1] * self.tile_size,   # position of the tile
                        self.tile_size, self.tile_size                                      # size of the tile
                    )
                )
        return rects
    
    def autotile(self):
        for loc in self.tilemap:
            tile = self.tilemap[loc]
            neighbors = set()
            for shift in [(1, 0), (-1, 0), (0, -1), (0, 1)]:
                check_loc = str(tile['pos'][0] + shift[0]) + ";" + str(tile['pos'][1] + shift[1])
                if check_loc in self.tilemap:
                    if self.tilemap[check_loc]['type'] == tile['type']:     # Keep different groups from auto-tiling
                        neighbors.add(shift)

            neighbors = tuple(sorted(neighbors))
            if (tile['type'] in AUTOTILE_TYPES) and (neighbors in AUTOTILE_MAP):
                tile['variant'] = AUTOTILE_MAP[neighbors]
            
    def render(self, surf, offset = (0, 0)):
        # "type" = category (subfolder) of image
        # "variant" = index (file) of image
        # at position [x,y]
        # NOT scaled with "tile_size", hence why it is "offgrid_tiles"
        for tile in self.offgrid_tiles:
            surf.blit(
                self.game.assets[tile["type"]][tile["variant"]],
                (tile['pos'][0] - offset[0], tile['pos'][1] - offset[1])
            )

        # Optimized code: runs faster when num_tiles_on_cam ~>= num_air_on_cam
        for x in range(offset[0] // self.tile_size, (offset[0] + surf.get_width()) // self.tile_size + 1):      # (left-most block), (right-most block) + 1 to stay in-bounds for the array
            for y in range(offset[1] // self.tile_size, (offset[1] + surf.get_height()) // self.tile_size + 1):      # (top block), (bottom block) + 1 to stay in-bounds for the array
                loc = str(x) + ";" + str(y)     # individual block location
                if loc in self.tilemap:
                    tile = self.tilemap[loc]
                    surf.blit(
                        self.game.assets[tile["type"]][tile["variant"]],
                        (tile["pos"][0] * self.tile_size - offset[0], tile["pos"][1] * self.tile_size - offset[1])
                    )