
import os
import pygame
from pathlib import Path

# BASE_IMG_PATH = "src/data/images/"
SRC_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = str(SRC_DIR) + "/data/"
BASE_IMG_PATH = DATA_DIR + "images/"

def load_image(path):
    img = pygame.image.load(BASE_IMG_PATH + path).convert()
    img.set_colorkey((0,0,0))
    return img

def load_images(path):
    images = []
    # sorted ensures 0 is before 1 independant of OS
    # 10 comes before 2-9, must pad with 0's
    # i.e 000, 001, 002 ... 010, 011, 012 ... 100, 101, 102, + n
    for img_name in sorted(os.listdir(BASE_IMG_PATH + path)):       # os.listdir provides all files in a path
        images.append(load_image(path + "/" + img_name))
        # print(img_name)       # use to figure out wrong libpng warning

    return images

def load_music(music_id, volume=0.5, loop=True):
    pygame.mixer.music.load(DATA_DIR + 'music/' + music_id)
    pygame.mixer.music.set_volume(volume)
    if loop:
        pygame.mixer.music.play(-1)
    else:
        pygame.mixer.music.play(1)

class Animation:
    def __init__(self, images, img_dur=5, loop=True):
        self.images = images
        self.loop = loop
        self.img_duration = img_dur
        self.done = False       # When not looping, set to true when animation finishes
        self.frame = 0          # Tracks animation progress; frame is game-frame

    def copy(self):
        return Animation(self.images, self.img_duration, self.loop)
    
    def update(self):
        if self.loop:
            self.frame = (self.frame + 1) % (self.img_duration * len(self.images))      # len(self.images) keeps self.frame from giving an index error. See function img() for example.
        else:
            self.frame = min(self.frame + 1, self.img_duration * len(self.images) - 1)
            if self.frame >= self.img_duration * len(self.images) - 1:      # when the last image is reached or surpassed, end the loop
                self.done = True

    def img(self):
        return self.images[int(self.frame / self.img_duration)]     # increment the image every img_dur frames
