
import asyncio
import sys
import os
import math
import random
import pygame
import json
from pathlib import Path

from scripts.utils import load_image, load_images, load_music, Animation
from scripts.entities import Player, Enemy
from scripts.tilemap import Tilemap
from scripts.clouds import Clouds
from scripts.particle import Particle
from scripts.spark import Spark

# async def main():
PATH_SRC = str(Path(__file__).resolve().parent) + "/"       # .../src
PATH_DATA = PATH_SRC + "/data/"                             # .../src/data

# Get magic numbers. Used for many variables
f = open(PATH_SRC + 'magic_num.json', 'r')
magic_num = json.load(f)
f.close()

class Game:
    def __init__(self):
        pygame.init()

        # Set up screen name and size
        pygame.display.set_caption("Novara's Ascent")
        pygame.display.set_icon(pygame.image.load(PATH_DATA + 'images/icon/icon_2.png'))
        self.SCREEN_SIZE = (1280, 720)       # Look into magic numbers to set a size.
        self.screen = pygame.display.set_mode(size=self.SCREEN_SIZE)  # The actual Window's window.

        self.display = pygame.Surface((640, 360), pygame.SRCALPHA)      # What everything is render to
        self.display_2 = pygame.Surface((640, 360))     # Use for images not receiving an outline
        self.scaled_display = pygame.Surface(self.SCREEN_SIZE)

        # Create clock for framerate
        self.clock = pygame.time.Clock()

        self.movement = [False, False]
        
        self.assets = {
            "grass": load_images("tiles/grass"),
            'transition': load_images('tiles/transition'),
            "spike": load_images('tiles/spikes/dirt'),
            "flowers": load_images("tiles/decor/flowers"),
            "grapes": load_images("tiles/decor/grapes"),
            "trees": load_images("tiles/decor/trees"),
            "wells": load_images("tiles/decor/wells"),
            "background": load_image("backgrounds/1.png"),
            "clouds": load_images("clouds"),
            "enemy/idle": Animation(load_images("entities/enemy/idle"), img_dur=6),
            "enemy/run": Animation(load_images("entities/enemy/run"), img_dur=4),
            "player/idle": Animation(load_images("entities/player/idle"), img_dur=21),
            "player/run": Animation(load_images("entities/player/run"), img_dur=4),
            "player/jump": Animation(load_images("entities/player/jump"), img_dur=7),
            "player/pick": Animation(load_images('entities/player/pick'), img_dur=1),
            "player/wall_slide": Animation(load_images("entities/player/wall_slide"), img_dur=10),
            'particle/particle': Animation(load_images('particles/particle'), img_dur=6, loop=False),
            'gun': load_image('gun.png'),
            'projectile': load_image('projectile.png'),
            'death': load_images('tiles/util/game'),
            'grape': load_images('tiles/collectable/grape/idle'),
            'wine': load_images('tiles/collectable/wine/idle'),
        }

        self.sfx = {
            'jump': pygame.mixer.Sound(PATH_DATA + 'sfx/jump.ogg'),
            'dash': pygame.mixer.Sound(PATH_DATA + 'sfx/dash.ogg'),
            'hit': pygame.mixer.Sound(PATH_DATA + 'sfx/hit.ogg'),
            'shoot': pygame.mixer.Sound(PATH_DATA + 'sfx/shoot.ogg'),
            'ambience': pygame.mixer.Sound(PATH_DATA + 'sfx/ambience.ogg'),
        }

        self.sfx['ambience'].set_volume(0.2)
        self.sfx['shoot'].set_volume(0.4)
        self.sfx['hit'].set_volume(0.8)
        self.sfx['dash'].set_volume(0.3)
        self.sfx['jump'].set_volume(0.6)

        self.clouds = Clouds(self.assets["clouds"], count=16)

        self.player = Player(self, (50, 150), (10, 15))

        self.tilemap = Tilemap(self, tile_size=8)

        self.level = magic_num['level']
        self.load_level(self.level)

        self.screenshake = 0

    def load_level(self, map_id):
        if map_id < 10: map_id = "0" + str(map_id)
        self.tilemap.load(PATH_DATA + 'maps/' + str(map_id) + '.json')

        # hack for particle spawner
        # this method only works for the trees
        self.leaf_spawners = []
        for tree in self.tilemap.extract([(PATH_DATA + 'images/tiles/decor/trees', 2)], keep=True):
            # creates a hitbox for the particle spawner
            self.leaf_spawners.append(
                pygame.Rect(4 + tree['pos'][0], 4 + tree['pos'][1], 23, 13)     # sets hitbox to be a rectangle on the upper half of the tree
            )

        self.enemies = []
        for spawner in self.tilemap.extract([('spawners', 0), ('spawners', 1)]):
            if spawner['variant'] == 0:
                self.player.pos = spawner['pos']
                self.player.air_time = 0
            else:
                self.enemies.append(Enemy(self, spawner['pos'], (8, 15)))

        self.projectiles = []
        self.particles = []
        self.sparks = []

        self.scroll = [0, 0]    # Start camera in top-left of screen
        self.dead = 0
        self.transition = -30       # -30, 30 -> no vision; 0 -> full vision

    async def run(self):

        # Load music
        music_id = magic_num["music"]["world1"][int(self.level)]
        load_music(music_id=music_id)
        self.sfx['ambience'].play(-1)

        while True:
            self.display.fill((0, 0, 0, 0))
            self.display_2.blit(self.assets["background"], (0, 0))      # set window background
            self.screenshake = max(0, self.screenshake - 1)

            if not len(self.enemies):
                self.transition += 1
                if self.transition > 30:
                    # WARNING: Because os.listdir(PATH_DATA + 'maps') looks the number of files in ..data/maps,
                    #          adding any more files will cause an IndexError.
                    self.level = min(self.level + 1, len(os.listdir(PATH_DATA + 'maps')) - 1)
                    self.load_level(self.level)

                    # Load music
                    music_id = magic_num["music"]["world1"][int(self.level)]
                    load_music(music_id=music_id)
            if self.transition < 0:
                self.transition += 1    

            # Create death timer on death
            if self.dead:       # Start at 0 = False
                self.dead += 1
                if self.dead >= 10:     # start transition on player death
                    self.transition = min(30, self.transition + 1)
                if self.dead > 40:
                    self.load_level(self.level)

            self.scroll[0] += (self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]) / 30     # Center player horizontally on screen at a rate of (pos / c)
            self.scroll[1] += (self.player.rect().centery - self.display.get_width() / 3 - self.scroll[1]) / 30      # Center player vertically on screen at a rate of (pos / c)
            render_scroll = (int(self.scroll[0]), int(self.scroll[1]))      # Used to prevent player from visually oscillating up and down

            # Search in leaf_spawners
            for rect in self.leaf_spawners:
                # random() * c controls the rate of leave spawning, where
                # random() < rect sets rate proportional to tree size; Bigger tree -> more leaves
                if random.random() * 49999 < rect.width * rect.height:
                    # set leaf spawn position
                    pos = (
                        rect.x + random.random() * rect.width,      # x-cor; img left edge + (range(0, 1) * img right edge)
                        rect.y + random.random() * rect.height      # y-cor; img top edge + (range(0, 1) * img bottom edge)
                    )

            self.clouds.update()
            self.clouds.render(self.display_2, offset=render_scroll)

            self.tilemap.render(self.display, offset = render_scroll)       # Rendered before player to place "underneath"

            for enemy in self.enemies.copy():
                kill = enemy.update(self.tilemap, (0, 0))
                enemy.render(self.display, offset=render_scroll)
                if kill:
                    self.enemies.remove(enemy)

            if not self.dead:
                self.player.update(self.tilemap, (self.movement[1] - self.movement[0], 0))      # update X coordinate
                self.player.render(self.display, offset = render_scroll)

            # projectile array -> [[x-cor, y-cor], dir, timer]
            for projectile in self.projectiles.copy():
                projectile[0][0] += projectile[1]       # increase x-pos
                projectile[2] += 1                      # increase timer
                img = self.assets['projectile']         # used to reference assets more easily
                self.display.blit(
                    img,
                    (
                        projectile[0][0] - img.get_width() / 2 - render_scroll[0],
                        projectile[0][1] - img.get_height() / 2 - render_scroll[1]
                    )
                )
                # Handle projectile collision/expiration
                if self.tilemap.solid_check(projectile[0]):     # Kill on wall collision
                    self.projectiles.remove(projectile)
                    for i in range(4):
                        self.sparks.append(Spark(projectile[0], random.random() - 0.5 + (math.pi if projectile[1] > 0 else 0), 2 + random.random()))
                elif projectile[2] > 360:                       # Kill on timer expiration
                    self.projectiles.remove(projectile)
                elif abs(self.player.dashing) < 50:             # Contact player when not actively dashing
                    if self.player.rect().collidepoint(projectile[0]):
                        self.projectiles.remove(projectile)
                        self.dead += 1
                        self.sfx['hit'].play()
                        self.screenshake = max(16, self.screenshake)
                        for i in range(30):
                            angle = random.random() * math.pi * 2
                            speed = random.random() * 5
                            self.sparks.append(Spark(self.player.rect().center, angle, 2 + random.random()))
                            

            for spark in self.sparks.copy():
                kill = spark.update()
                spark.render(self.display, offset=render_scroll)
                if kill:
                    self.sparks.remove(spark)

            # Particle management
            for particle in self.particles.copy():
                kill = particle.update()        # Check if particle needs to be killed
                particle.render(self.display, offset=render_scroll)
                # sway leave horizontally
                if particle.type == 'leaf':
                    # 0.035 slows the sway
                    # 0.3 reduce sway domain
                    particle.pos[0] += math.sin(particle.animation.frame * 0.035) * 0.3
                if kill:
                    self.particles.remove(particle)

            # Event management
            for event in pygame.event.get():
                # Check if Windows "Close" tab is selected
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit
                # Check if key is pressed
                if event.type == pygame.KEYDOWN:
                    # Player movement
                    if event.key == pygame.K_LEFT:
                        self.movement[0] = True
                    if event.key == pygame.K_RIGHT:
                        self.movement[1] = True
                    if event.key == pygame.K_UP or event.key == pygame.K_SPACE:
                        if self.player.jump():
                            self.sfx['jump'].play()
                    if event.key == pygame.K_c:
                        self.player.dash()
                    # Menuing
                    if event.key == pygame.K_F11:
                        pygame.display.toggle_fullscreen()
                # Check if key is released
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        self.movement[0] = False
                    if event.key == pygame.K_RIGHT:
                        self.movement[1] = False
                    if event.key == pygame.K_UP or event.key == pygame.K_SPACE:
                        self.player.velocity[1] = max(-1, self.player.velocity[1])

            # run transition
            if self.transition:
                transition_surf = pygame.Surface(self.display.get_size())       # make black surface
                pygame.draw.circle(transition_surf, (255, 255, 255), (self.display.get_width() // 2, self.display.get_height() // 2), (30 - abs(self.transition)) * 8)
                transition_surf.set_colorkey((255, 255, 255))       # use to hide the circle of white; The game can be seen "through" the circle
                self.display.blit(transition_surf, (0, 0))

            self.display_2.blit(self.display, (0, 0))       # draw main display back on top

            screenshake_offset = (random.random() * self.screenshake - self.screenshake / 2, random.random() * self.screenshake - self.screenshake / 2)
            self.screen.blit(pygame.transform.scale(self.display_2, self.screen.get_size()), screenshake_offset)       # draw the display onto the screen at [0, 0], at scale
            pygame.display.update()     # Re-draw screen
            self.clock.tick(60)         # Set fps

            await asyncio.sleep(0)


async def main():
    game = Game()
    await game.run()

asyncio.run(main())